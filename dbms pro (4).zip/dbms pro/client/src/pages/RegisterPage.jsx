import { useState } from "react";
import api from "../api";

export default function RegisterPage() {
  const [form, setForm] = useState({
    name: "",
    age: "",
    gender: "Female",
    blood_group: "O+",
    contact: "",
    role: "donor",
    donor_organ_type: "",
    donor_expiry_hours: 24,
    organ_type_needed: "",
    urgency: 3,
    waiting_time: 0
  });
  const [message, setMessage] = useState("");

  const onSubmit = async (e) => {
    e.preventDefault();
    try {
      const payload = {
        ...form,
        age: Number(form.age),
        urgency: Number(form.urgency),
        donor_expiry_hours: Number(form.donor_expiry_hours),
        waiting_time: Number(form.waiting_time),
        auto_match: form.role === "recipient"
      };
      const res = await api.post("/register", payload);
      const base = `${res.data.message} ID: ${res.data.person.person_id}`;
      if (res.data.autoMatchResult?.matched) {
        setMessage(`${base}. Auto-match created (Match ID: ${res.data.autoMatchResult.match_id}).`);
      } else {
        setMessage(base);
      }
    } catch (error) {
      setMessage(error.response?.data?.message || "Registration failed.");
    }
  };

  return (
    <section className="rounded-lg bg-white p-6 shadow">
      <h2 className="mb-4 text-2xl font-semibold">Register Person</h2>
      <p className="mb-4 text-sm text-slate-600">
        Donor registration can store organ details immediately. Recipient registration can create waiting
        list entry with priority = urgency + waiting time.
      </p>
      <form className="grid gap-4 md:grid-cols-2" onSubmit={onSubmit}>
        <label className="flex flex-col gap-1 text-sm">
          Name
          <input
            className="rounded border p-2"
            placeholder="Full name"
            onChange={(e) => setForm({ ...form, name: e.target.value })}
          />
        </label>
        <label className="flex flex-col gap-1 text-sm">
          Age
          <input
            className="rounded border p-2"
            placeholder="Age"
            type="number"
            onChange={(e) => setForm({ ...form, age: e.target.value })}
          />
        </label>
        <label className="flex flex-col gap-1 text-sm">
          Gender
          <select
            className="rounded border p-2"
            value={form.gender}
            onChange={(e) => setForm({ ...form, gender: e.target.value })}
          >
            <option value="Female">Female</option>
            <option value="Male">Male</option>
            <option value="Other">Other</option>
          </select>
        </label>
        <label className="flex flex-col gap-1 text-sm">
          Blood Group
          <select className="rounded border p-2" value={form.blood_group} onChange={(e) => setForm({ ...form, blood_group: e.target.value })}>
            {["O-", "O+", "A-", "A+", "B-", "B+", "AB-", "AB+"].map((bg) => (
              <option key={bg}>{bg}</option>
            ))}
          </select>
        </label>
        <label className="flex flex-col gap-1 text-sm">
          Contact
          <input className="rounded border p-2" placeholder="Phone number" onChange={(e) => setForm({ ...form, contact: e.target.value })} />
        </label>
        <label className="flex flex-col gap-1 text-sm">
          Role
          <select className="rounded border p-2" value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}>
            <option value="donor">Donor</option>
            <option value="recipient">Recipient</option>
          </select>
        </label>
        {form.role === "donor" && (
          <>
            <label className="flex flex-col gap-1 text-sm">
              Organ to Donate
              <input
                className="rounded border p-2"
                placeholder="e.g. Kidney"
                value={form.donor_organ_type}
                onChange={(e) => setForm({ ...form, donor_organ_type: e.target.value })}
              />
            </label>
            <label className="flex flex-col gap-1 text-sm">
              Organ Expiry Window (hours)
              <input
                className="rounded border p-2"
                type="number"
                min="1"
                value={form.donor_expiry_hours}
                onChange={(e) => setForm({ ...form, donor_expiry_hours: e.target.value })}
                placeholder="24"
              />
            </label>
          </>
        )}
        {form.role === "recipient" && (
          <>
            <label className="flex flex-col gap-1 text-sm">
              Organ Needed
              <input
                className="rounded border p-2"
                placeholder="e.g. Liver"
                value={form.organ_type_needed}
                onChange={(e) => setForm({ ...form, organ_type_needed: e.target.value })}
              />
            </label>
            <label className="flex flex-col gap-1 text-sm">
              Urgency (1-5)
              <input
                className="rounded border p-2"
                type="number"
                min="1"
                max="5"
                value={form.urgency}
                onChange={(e) => setForm({ ...form, urgency: e.target.value })}
              />
            </label>
            <label className="flex flex-col gap-1 text-sm">
              Waiting Time (days)
              <input
                className="rounded border p-2"
                type="number"
                min="0"
                value={form.waiting_time}
                onChange={(e) => setForm({ ...form, waiting_time: e.target.value })}
              />
            </label>
          </>
        )}
        <button className="rounded bg-blue-700 px-4 py-2 text-white hover:bg-blue-800 md:col-span-2">
          Register
        </button>
      </form>
      {message && <p className="mt-4 text-sm text-emerald-700">{message}</p>}
    </section>
  );
}
