import { useEffect, useState } from "react";
import api from "../api";

export default function WaitingListPage() {
  const [rows, setRows] = useState([]);

  useEffect(() => {
    api.get("/waiting-list").then((res) => setRows(res.data)).catch(() => setRows([]));
  }, []);

  return (
    <section className="rounded-lg bg-white p-6 shadow">
      <h2 className="mb-4 text-2xl font-semibold">Waiting List</h2>
      <div className="overflow-x-auto">
        <table className="min-w-full border text-sm">
          <thead className="bg-slate-100">
            <tr>
              <th className="border p-2">Recipient</th>
              <th className="border p-2">Blood Group</th>
              <th className="border p-2">Organ Needed</th>
              <th className="border p-2">Urgency x5</th>
              <th className="border p-2">Waiting x2</th>
              <th className="border p-2">Age Score</th>
              <th className="border p-2">Critical Organ</th>
              <th className="border p-2">Priority Score</th>
              <th className="border p-2">Rank</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row.entry_id}>
                <td className="border p-2">{row.recipient?.person?.name}</td>
                <td className="border p-2">{row.recipient?.person?.blood_group}</td>
                <td className="border p-2">{row.recipient?.organ_needed || "-"}</td>
                <td className="border p-2">{row.priority_breakdown?.urgencyScore ?? "-"}</td>
                <td className="border p-2">{row.priority_breakdown?.waitingScore ?? "-"}</td>
                <td className="border p-2">{row.priority_breakdown?.ageScore ?? "-"}</td>
                <td className="border p-2">{row.priority_breakdown?.organCriticalScore ?? "-"}</td>
                <td className="border p-2">{row.priority_score}</td>
                <td className="border p-2">{row.rank_position ?? "-"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}
