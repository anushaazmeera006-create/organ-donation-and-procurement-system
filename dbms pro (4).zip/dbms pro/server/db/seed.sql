USE organ_system;

SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE match_table;
TRUNCATE TABLE waiting_list;
TRUNCATE TABLE audit_log;
TRUNCATE TABLE organ;
TRUNCATE TABLE recipient;
TRUNCATE TABLE donor;
TRUNCATE TABLE hospital;
TRUNCATE TABLE person;
SET FOREIGN_KEY_CHECKS = 1;

INSERT INTO person (name, age, gender, blood_group, phone) VALUES
('Rahul',25,'Male','O+','9000000001'),
('Amit',30,'Male','A+','9000000002'),
('Priya',28,'Female','B+','9000000003'),
('Sneha',32,'Female','AB+','9000000004'),
('Karan',26,'Male','O-','9000000005'),
('Riya',29,'Female','A-','9000000006'),
('Vikas',35,'Male','B-','9000000007'),
('Neha',27,'Female','O+','9000000008'),
('Arjun',31,'Male','A+','9000000009'),
('Pooja',24,'Female','B+','9000000010'),
('Rohit',33,'Male','AB+','9000000011'),
('Simran',26,'Female','O-','9000000012'),
('Anil',40,'Male','A-','9000000013'),
('Meena',38,'Female','B-','9000000014'),
('Deepak',22,'Male','O+','9000000015'),
('Kavya',23,'Female','A+','9000000016'),
('Manish',34,'Male','B+','9000000017'),
('Nikita',29,'Female','AB+','9000000018'),
('Suresh',45,'Male','O-','9000000019'),
('Ananya',21,'Female','A-','9000000020'),
('Harsh',27,'Male','B-','9000000021'),
('Tanya',25,'Female','O+','9000000022'),
('Varun',36,'Male','A+','9000000023'),
('Isha',28,'Female','B+','9000000024'),
('Naveen',39,'Male','AB+','9000000025'),
('Divya',30,'Female','O-','9000000026'),
('Rakesh',41,'Male','A-','9000000027'),
('Shreya',22,'Female','B-','9000000028'),
('Gaurav',33,'Male','O+','9000000029'),
('Komal',27,'Female','A+','9000000030'),
('Yash',24,'Male','B+','9000000031'),
('Aisha',26,'Female','AB+','9000000032'),
('Sanjay',37,'Male','O-','9000000033'),
('Reema',31,'Female','A-','9000000034'),
('Tarun',29,'Male','B-','9000000035'),
('Payal',23,'Female','O+','9000000036'),
('Mohit',35,'Male','A+','9000000037'),
('Pallavi',28,'Female','B+','9000000038'),
('Ajay',42,'Male','AB+','9000000039'),
('Ritu',34,'Female','O-','9000000040');

INSERT INTO donor (donor_id, consent) VALUES
(1,TRUE),(2,TRUE),(3,TRUE),(4,TRUE),(5,TRUE),
(6,TRUE),(7,TRUE),(8,TRUE),(9,TRUE),(10,TRUE),
(11,TRUE),(12,TRUE),(13,TRUE),(14,TRUE),(15,TRUE),
(16,TRUE),(17,TRUE),(18,TRUE),(19,TRUE),(20,TRUE);

INSERT INTO recipient (recipient_id, organ_needed, urgency_level) VALUES
(21,'Kidney',5),(22,'Liver',4),(23,'Heart',5),(24,'Lung',3),
(25,'Kidney',2),(26,'Liver',5),(27,'Heart',4),(28,'Lung',3),
(29,'Kidney',5),(30,'Liver',2),(31,'Heart',4),(32,'Lung',3),
(33,'Kidney',5),(34,'Liver',4),(35,'Heart',3),(36,'Lung',2),
(37,'Kidney',5),(38,'Liver',4),(39,'Heart',3),(40,'Lung',2);

INSERT INTO organ (donor_id, organ_type, expiry_time) VALUES
(1,'Kidney',NOW()+INTERVAL 24 HOUR),
(2,'Liver',NOW()+INTERVAL 24 HOUR),
(3,'Heart',NOW()+INTERVAL 12 HOUR),
(4,'Lung',NOW()+INTERVAL 12 HOUR),
(5,'Kidney',NOW()+INTERVAL 24 HOUR),
(6,'Liver',NOW()+INTERVAL 24 HOUR),
(7,'Heart',NOW()+INTERVAL 12 HOUR),
(8,'Lung',NOW()+INTERVAL 12 HOUR),
(9,'Kidney',NOW()+INTERVAL 24 HOUR),
(10,'Liver',NOW()+INTERVAL 24 HOUR),
(11,'Heart',NOW()+INTERVAL 12 HOUR),
(12,'Lung',NOW()+INTERVAL 12 HOUR),
(13,'Kidney',NOW()+INTERVAL 24 HOUR),
(14,'Liver',NOW()+INTERVAL 24 HOUR),
(15,'Heart',NOW()+INTERVAL 12 HOUR),
(16,'Lung',NOW()+INTERVAL 12 HOUR),
(17,'Kidney',NOW()+INTERVAL 24 HOUR),
(18,'Liver',NOW()+INTERVAL 24 HOUR),
(19,'Heart',NOW()+INTERVAL 12 HOUR),
(20,'Lung',NOW()+INTERVAL 12 HOUR);

INSERT INTO hospital (name, location) VALUES
('AIIMS','Delhi'),
('Apollo','Chennai'),
('Fortis','Mumbai'),
('Max Hospital','Delhi'),
('Medanta','Gurgaon'),
('Narayana','Bangalore'),
('Care Hospital','Hyderabad'),
('Ruby Hall','Pune'),
('CMC','Vellore'),
('KIMS','Hyderabad');

INSERT INTO match_table (donor_id, recipient_id, organ_id, hospital_id, status) VALUES
(1,21,1,1,'completed'),
(2,22,2,2,'completed'),
(3,23,3,3,'pending'),
(4,24,4,4,'completed'),
(5,25,5,5,'pending'),
(6,26,6,6,'completed'),
(7,27,7,7,'pending'),
(8,28,8,8,'completed'),
(9,29,9,9,'pending'),
(10,30,10,10,'completed'),
(11,31,11,1,'pending'),
(12,32,12,2,'completed'),
(13,33,13,3,'pending'),
(14,34,14,4,'completed'),
(15,35,15,5,'pending'),
(16,36,16,6,'completed'),
(17,37,17,7,'pending'),
(18,38,18,8,'completed'),
(19,39,19,9,'pending'),
(20,40,20,10,'completed');

INSERT INTO waiting_list (recipient_id, priority_score, rank_position) VALUES
(21,95,1),(22,90,2),(23,98,3),(24,85,4),
(25,80,5),(26,97,6),(27,92,7),(28,88,8),
(29,96,9),(30,75,10),(31,91,11),(32,87,12),
(33,99,13),(34,93,14),(35,89,15),(36,70,16),
(37,97,17),(38,94,18),(39,88,19),(40,72,20);

INSERT INTO audit_log (action, details) VALUES
('Insert','Donor added'),
('Insert','Recipient added'),
('Match','Organ matched'),
('Update','Status updated'),
('Insert','Hospital added'),
('Match','Allocation done'),
('Update','Waiting list updated'),
('Insert','Organ added'),
('Delete','Old record removed'),
('Match','Transplant completed');
