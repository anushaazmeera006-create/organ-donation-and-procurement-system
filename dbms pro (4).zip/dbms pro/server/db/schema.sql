CREATE DATABASE IF NOT EXISTS organ_system;
USE organ_system;

CREATE TABLE person (
    person_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    age INT CHECK (age > 0),
    gender VARCHAR(10),
    blood_group VARCHAR(5),
    phone VARCHAR(15)
);

CREATE TABLE donor (
    donor_id INT PRIMARY KEY,
    status VARCHAR(20) DEFAULT 'active',
    consent BOOLEAN NOT NULL,
    FOREIGN KEY (donor_id) REFERENCES person(person_id)
        ON DELETE CASCADE
);

CREATE TABLE recipient (
    recipient_id INT PRIMARY KEY,
    organ_needed VARCHAR(50),
    urgency_level INT CHECK (urgency_level BETWEEN 1 AND 5),
    waiting_time INT DEFAULT 0,
    status VARCHAR(20) DEFAULT 'waiting',
    FOREIGN KEY (recipient_id) REFERENCES person(person_id)
        ON DELETE CASCADE
);

CREATE TABLE organ (
    organ_id INT AUTO_INCREMENT PRIMARY KEY,
    donor_id INT,
    organ_type VARCHAR(50),
    availability_status VARCHAR(20) DEFAULT 'available',
    expiry_time DATETIME,
    FOREIGN KEY (donor_id) REFERENCES donor(donor_id)
        ON DELETE SET NULL
);

CREATE TABLE hospital (
    hospital_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    location VARCHAR(100)
);

CREATE TABLE match_table (
    match_id INT AUTO_INCREMENT PRIMARY KEY,
    donor_id INT,
    recipient_id INT,
    organ_id INT,
    hospital_id INT,
    match_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20),
    FOREIGN KEY (donor_id) REFERENCES donor(donor_id),
    FOREIGN KEY (recipient_id) REFERENCES recipient(recipient_id),
    FOREIGN KEY (organ_id) REFERENCES organ(organ_id),
    FOREIGN KEY (hospital_id) REFERENCES hospital(hospital_id)
);

CREATE TABLE waiting_list (
    entry_id INT AUTO_INCREMENT PRIMARY KEY,
    recipient_id INT,
    priority_score FLOAT,
    rank_position INT,
    FOREIGN KEY (recipient_id) REFERENCES recipient(recipient_id)
        ON DELETE CASCADE
);

CREATE TABLE audit_log (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    action VARCHAR(100),
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    details TEXT
);

CREATE INDEX idx_blood_group ON person(blood_group);
CREATE INDEX idx_organ_type ON organ(organ_type);
