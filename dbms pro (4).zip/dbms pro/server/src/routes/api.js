import express from "express";
import prisma from "../prisma.js";
import { isBloodCompatible } from "../services/bloodCompatibility.js";

const router = express.Router();
const BLOOD_GROUPS = ["O-", "O+", "A-", "A+", "B-", "B+", "AB-", "AB+"];
const ORGAN_TYPES = ["Kidney", "Liver", "Heart", "Lung", "Pancreas", "Cornea"];

function calculatePriority(urgency, requestDate) {
  const waitingTimeDays = Math.max(
    0,
    Math.floor((Date.now() - new Date(requestDate).getTime()) / (1000 * 60 * 60 * 24))
  );
  return urgency + waitingTimeDays;
}

async function addAudit(action, details = null) {
  await prisma.auditLog.create({ data: { action, details } });
}

function validateBloodGroup(bg) {
  return BLOOD_GROUPS.includes(bg);
}

function normalizeOrganType(organType) {
  if (!organType) return null;
  const found = ORGAN_TYPES.find((t) => t.toLowerCase() === organType.toLowerCase());
  return found || organType;
}

function calculatePriorityDetailed({ urgency, waitingTime, age, organType }) {
  const urgencyScore = Number(urgency || 0) * 5;
  const waitingScore = Number(waitingTime || 0) * 2;
  const ageScore = age >= 60 ? 3 : age >= 45 ? 2 : 1;
  const organCriticalScore = ["Heart", "Lung"].includes(normalizeOrganType(organType)) ? 2 : 0;
  const total = urgencyScore + waitingScore + ageScore + organCriticalScore;
  return { urgencyScore, waitingScore, ageScore, organCriticalScore, total };
}

async function rerankWaitingList() {
  const rows = await prisma.waitingList.findMany({
    include: { recipient: true },
    orderBy: [{ priority_score: "desc" }, { entry_id: "asc" }]
  });

  let rank = 1;
  await Promise.all(
    rows.map((row) =>
      prisma.waitingList.update({
        where: { entry_id: row.entry_id },
        data: { rank_position: row.recipient?.status === "waiting" ? rank++ : 0 }
      })
    )
  );
}

router.post("/register", async (req, res) => {
  try {
    const {
      name,
      age,
      blood_group,
      contact,
      role,
      urgency,
      organ_type_needed,
      gender,
      donor_organ_type,
      donor_expiry_hours,
      waiting_time,
      auto_match
    } = req.body;

    if (!name || !age || !blood_group || !contact || !role) {
      return res.status(400).json({ message: "Missing required fields." });
    }
    if (!validateBloodGroup(blood_group)) {
      return res.status(400).json({ message: "Invalid blood group." });
    }
    if (!/^[0-9]{10,15}$/.test(String(contact))) {
      return res.status(400).json({ message: "Contact must be 10-15 digits." });
    }
    if (!["donor", "recipient"].includes(role)) {
      return res.status(400).json({ message: "Role must be donor or recipient." });
    }
    if (role === "recipient" && (!urgency || urgency < 1 || urgency > 5)) {
      return res.status(400).json({ message: "Recipient urgency must be 1-5." });
    }

    const person = await prisma.person.create({
      data: { name, age: Number(age), blood_group, phone: contact, gender: gender || null }
    });

    if (role === "donor") {
      await prisma.donor.create({ data: { donor_id: person.person_id, consent: true } });
      if (donor_organ_type) {
        const expiryHours = Number.isFinite(Number(donor_expiry_hours))
          ? Number(donor_expiry_hours)
          : 24;
        const organType = normalizeOrganType(donor_organ_type);
        await prisma.organ.create({
          data: {
            donor_id: person.person_id,
            organ_type: organType,
            availability_status: "available",
            expiry_time: new Date(Date.now() + expiryHours * 60 * 60 * 1000)
          }
        });
      }
    } else {
      const waitingDays = Math.max(0, Number(waiting_time || 0));
      const details = calculatePriorityDetailed({
        urgency: Number(urgency),
        waitingTime: waitingDays,
        age: Number(age),
        organType: organ_type_needed
      });

      await prisma.recipient.create({
        data: {
          recipient_id: person.person_id,
          urgency_level: Number(urgency),
          waiting_time: waitingDays,
          organ_needed: normalizeOrganType(organ_type_needed) || null
        }
      });

      await prisma.waitingList.create({
        data: {
          recipient_id: person.person_id,
          priority_score: details.total
        }
      });
      await rerankWaitingList();
    }

    await addAudit(
      "registration",
      `${role} ${name} (id: ${person.person_id}) blood=${blood_group}`
    );

    let autoMatchResult = null;
    if (role === "recipient" && auto_match === true) {
      const hospitals = await prisma.hospital.findMany();
      if (hospitals.length > 0) {
        const waitingEntries = await prisma.waitingList.findMany({
          include: { recipient: { include: { person: true } } },
          orderBy: [{ priority_score: "desc" }, { entry_id: "asc" }]
        });

        const currentEntry = waitingEntries.find((entry) => entry.recipient_id === person.person_id);
        if (currentEntry) {
          const compatibleOrgans = await prisma.organ.findMany({
            where: {
              organ_type: currentEntry.recipient.organ_needed,
              availability_status: "available"
            },
            include: { donor: { include: { person: true } } }
          });

          const selectedOrgan = compatibleOrgans.find((organ) => {
            const donorBlood = organ.donor?.person?.blood_group;
            const recipientBlood = currentEntry.recipient.person.blood_group;
            if (!donorBlood || !recipientBlood) return false;
            return isBloodCompatible(recipientBlood, donorBlood);
          });

          if (selectedOrgan?.donor_id) {
            const hospital = hospitals[0];
            const created = await prisma.$transaction(async (tx) => {
              const match = await tx.matchTable.create({
                data: {
                  organ_id: selectedOrgan.organ_id,
                  donor_id: selectedOrgan.donor_id,
                  recipient_id: currentEntry.recipient_id,
                  hospital_id: hospital.hospital_id,
                  status: "pending"
                }
              });
              await tx.organ.update({
                where: { organ_id: selectedOrgan.organ_id },
                data: { availability_status: "allocated" }
              });
              await tx.recipient.update({
                where: { recipient_id: currentEntry.recipient_id },
                data: { status: "completed" }
              });
              await tx.waitingList.delete({ where: { entry_id: currentEntry.entry_id } });
              return match;
            });

            autoMatchResult = {
              matched: true,
              match_id: created.match_id,
              hospital_id: hospital.hospital_id,
              organ_id: selectedOrgan.organ_id
            };
            await addAudit(
              "match created",
              `auto-match organ ${selectedOrgan.organ_id} -> recipient ${currentEntry.recipient_id}, hospital ${hospital.hospital_id}`
            );
          }
        }
      }
    }

    return res.status(201).json({
      message: "Registration successful.",
      person,
      autoMatchResult
    });
  } catch (error) {
    return res.status(500).json({ message: "Failed to register user.", error: error.message });
  }
});

router.post("/donor/add-organ", async (req, res) => {
  try {
    const { donor_id, organ_type, availability_status, expiry_time } = req.body;
    if (!donor_id || !organ_type) {
      return res.status(400).json({ message: "Missing required fields." });
    }

    const donor = await prisma.donor.findUnique({ where: { donor_id: Number(donor_id) } });
    if (!donor) return res.status(404).json({ message: "Donor not found." });

    const organ = await prisma.organ.create({
      data: {
        donor_id: Number(donor_id),
        organ_type: normalizeOrganType(organ_type),
        availability_status: availability_status === "allocated" ? "allocated" : "available",
        expiry_time: expiry_time ? new Date(expiry_time) : null
      }
    });

    await addAudit("organ added", `${organ_type} by donor ${donor_id}`);
    return res.status(201).json({ message: "Organ added successfully.", organ });
  } catch (error) {
    return res.status(500).json({ message: "Failed to add organ.", error: error.message });
  }
});

router.post("/recipient/request", async (req, res) => {
  try {
    const { recipient_id, organ_type_needed, urgency, waiting_time = 0, request_date } = req.body;
    if (!recipient_id || !organ_type_needed || !urgency) {
      return res.status(400).json({ message: "Missing required fields." });
    }
    if (urgency < 1 || urgency > 5) {
      return res.status(400).json({ message: "Urgency must be 1-5." });
    }

    const recipient = await prisma.recipient.findUnique({
      where: { recipient_id: Number(recipient_id) }
    });
    if (!recipient) return res.status(404).json({ message: "Recipient not found." });

    await prisma.recipient.update({
      where: { recipient_id: Number(recipient_id) },
      data: {
        urgency_level: Number(urgency),
        organ_needed: normalizeOrganType(organ_type_needed),
        waiting_time: Number(waiting_time || 0),
        status: "waiting"
      }
    });

    const recipientAfter = await prisma.recipient.findUnique({
      where: { recipient_id: Number(recipient_id) },
      include: { person: true }
    });
    const details = calculatePriorityDetailed({
      urgency: Number(urgency),
      waitingTime: Number(waiting_time || 0),
      age: recipientAfter?.person?.age || 0,
      organType: organ_type_needed
    });
    const existing = await prisma.waitingList.findFirst({
      where: { recipient_id: Number(recipient_id), rank_position: { gt: 0 } }
    });
    const waitingEntry = existing
      ? await prisma.waitingList.update({
          where: { entry_id: existing.entry_id },
          data: { priority_score: details.total }
        })
      : await prisma.waitingList.create({
          data: {
            recipient_id: Number(recipient_id),
            priority_score: details.total
          }
        });
    await rerankWaitingList();

    await addAudit(
      "recipient request",
      `recipient ${recipient_id}, organ ${organ_type_needed}, priority ${details.total}`
    );
    return res.status(201).json({ message: "Organ request added to waiting list.", waitingEntry });
  } catch (error) {
    return res.status(500).json({ message: "Failed to submit request.", error: error.message });
  }
});

router.get("/organs", async (_req, res) => {
  try {
    const organs = await prisma.organ.findMany({
      include: { donor: { include: { person: true } } },
      orderBy: { organ_id: "asc" }
    });
    return res.json(organs);
  } catch (error) {
    return res.status(500).json({ message: "Failed to fetch organs.", error: error.message });
  }
});

router.get("/donors", async (_req, res) => {
  try {
    const donors = await prisma.donor.findMany({
      include: {
        person: true,
        organs: true
      },
      orderBy: { donor_id: "asc" }
    });
    return res.json(donors);
  } catch (error) {
    return res.status(500).json({ message: "Failed to fetch donors.", error: error.message });
  }
});

router.get("/recipients", async (_req, res) => {
  try {
    const recipients = await prisma.recipient.findMany({
      include: {
        person: true
      },
      orderBy: { recipient_id: "asc" }
    });

    const enriched = await Promise.all(
      recipients.map(async (r) => {
        const log = await prisma.auditLog.findFirst({
          where: {
            action: {
              in: ["recipient request", "registration"]
            },
            details: {
              contains: `recipient ${r.recipient_id}`
            }
          },
          orderBy: { timestamp: "desc" }
        });
        return {
          ...r,
          lastRequestDate: log?.timestamp ?? null
        };
      })
    );

    return res.json(enriched);
  } catch (error) {
    return res.status(500).json({ message: "Failed to fetch recipients.", error: error.message });
  }
});

router.get("/waiting-list", async (_req, res) => {
  try {
    const waitingList = await prisma.waitingList.findMany({
      include: { recipient: { include: { person: true } } },
      orderBy: [{ priority_score: "desc" }, { entry_id: "asc" }]
    });
    const active = waitingList.filter((item) => item.recipient?.status === "waiting" && (item.rank_position || 0) > 0);
    const withBreakdown = active.map((item) => {
      const details = calculatePriorityDetailed({
        urgency: item.recipient?.urgency_level || 0,
        waitingTime: item.recipient?.waiting_time || 0,
        age: item.recipient?.person?.age || 0,
        organType: item.recipient?.organ_needed
      });
      return {
        ...item,
        priority_breakdown: details
      };
    });
    return res.json(withBreakdown);
  } catch (error) {
    return res.status(500).json({ message: "Failed to fetch waiting list.", error: error.message });
  }
});

router.post("/match/run", async (_req, res) => {
  try {
    const waitingEntries = await prisma.waitingList.findMany({
      include: {
        recipient: { include: { person: true } }
      }
    });
    const hospitals = await prisma.hospital.findMany();

    if (!hospitals.length) {
      return res.status(400).json({ message: "No hospitals available for assignment." });
    }

    const recomputed = waitingEntries.map((entry) => {
      const priority = calculatePriorityDetailed({
        urgency: entry.recipient.urgency_level,
        waitingTime: entry.recipient.waiting_time || 0,
        age: entry.recipient?.person?.age || 0,
        organType: entry.recipient?.organ_needed
      }).total;
      return { ...entry, priority_score: priority };
    });

    recomputed.sort((a, b) => b.priority_score - a.priority_score);

    const createdMatches = [];

    for (let i = 0; i < recomputed.length; i += 1) {
      const entry = recomputed[i];

      await prisma.waitingList.update({
        where: { entry_id: entry.entry_id },
        data: { priority_score: entry.priority_score }
      });

      const compatibleOrgans = await prisma.organ.findMany({
        where: {
          organ_type: entry.recipient.organ_needed,
          availability_status: "available"
        },
        include: {
          donor: { include: { person: true } }
        }
      });

      const selectedOrgan = compatibleOrgans.find((organ) => {
        const donorBlood = organ.donor?.person?.blood_group;
        const recipientBlood = entry.recipient.person.blood_group;
        if (!donorBlood || !recipientBlood) return false;
        return isBloodCompatible(recipientBlood, donorBlood);
      });

      if (!selectedOrgan) continue;

      const hospital = hospitals[createdMatches.length % hospitals.length];

      const match = await prisma.$transaction(async (tx) => {
        const created = await tx.matchTable.create({
          data: {
            organ_id: selectedOrgan.organ_id,
            donor_id: selectedOrgan.donor_id,
            recipient_id: entry.recipient_id,
            hospital_id: hospital.hospital_id,
            status: "pending"
          },
          include: {
            organ: true,
            recipient: { include: { person: true } },
            hospital: true
          }
        });

        await tx.organ.update({
          where: { organ_id: selectedOrgan.organ_id },
          data: { availability_status: "allocated" }
        });

        await tx.recipient.update({
          where: { recipient_id: entry.recipient_id },
          data: { status: "completed" }
        });

        // Soft delete style: keep history and mark this queue entry inactive.
        await tx.waitingList.update({
          where: { entry_id: entry.entry_id },
          data: { rank_position: 0 }
        });
        return created;
      });

      createdMatches.push(match);
      await addAudit(
        "match created",
        `organ ${selectedOrgan.organ_id} -> recipient ${entry.recipient_id}, hospital ${hospital.hospital_id} (${hospital.name})`
      );
    }

    return res.json({
      message: "Matching run completed.",
      matches_created: createdMatches.length,
      matches: createdMatches
    });
  } catch (error) {
    return res.status(500).json({ message: "Failed to run matching.", error: error.message });
  }
});

router.get("/matches", async (_req, res) => {
  try {
    const matches = await prisma.matchTable.findMany({
      include: {
        donor: { include: { person: true } },
        organ: true,
        recipient: { include: { person: true } },
        hospital: true
      },
      orderBy: { match_date: "desc" }
    });
    return res.json(matches);
  } catch (error) {
    return res.status(500).json({ message: "Failed to fetch matches.", error: error.message });
  }
});

router.get("/stats", async (_req, res) => {
  try {
    const [totalDonors, totalRecipients, totalMatches] = await Promise.all([
      prisma.donor.count(),
      prisma.recipient.count(),
      prisma.matchTable.count()
    ]);
    return res.json({ totalDonors, totalRecipients, totalMatches });
  } catch (error) {
    return res.status(500).json({ message: "Failed to fetch stats.", error: error.message });
  }
});

export default router;
